
                    <div class="card shadow mb-4">
                        <!-- Page Heading -->
                        <a href="#" class="d-block card-header py-3" aria-expanded="true" aria-controls="collapseCardExample">
                          <h6 class="m-0 font-weight-bold text-primary">PETUNJUK PENGGUNAAN!</h6>
                        </a>

                                <div class="d-block card-body py-3">                            
                                    <div class="collapse show" id="collapseCardExample">
                                      <div class="row">
                                        
                                        <div class="col-lg-12">
 <section class="container content">

 <h6 style="color:black;" ><b>
 1. Pertama Anda login terlebih dahulu atau jika belum memiliki akun anda dapat melakukan registrasi terlebih dahulu. 
 </b>
                                           </h6><hr>
                                           <h6 style="color:black;" >
                                           <b>2. Kemudian Anda pilih menu identifikasi. </b>
                                           </h6><hr>
                                           <h6 style="color:black;" >
                                           <b> 3. Lalu Anda bisa menjawab pertanyaan sesuai gejala yang Anda alami.</b>
                                           </h6><hr>
                                           <h6 style="color:black;" >
                                           <b>4. Setelah Anda selesai menjawab pertanyaan, maka akan tampil hasil identifikasi sesuai dengan gejala yang anda pilih sebelumnya.</b>
                                           </h6>


        </section>

                                        </div>

                                      </div>
                                      <hr>

                                    </div>

  
                                </div>
 
                        </div>
                        
                    </div>

                  </div>
