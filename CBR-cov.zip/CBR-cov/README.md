This project is a prototype of an expert system to diagnose COVID-19 symptons using case-based reasoning algorithm.




Tugas Akhir
Sistem Informasi
UIN Syarif Hidayatullah Jakarta.
