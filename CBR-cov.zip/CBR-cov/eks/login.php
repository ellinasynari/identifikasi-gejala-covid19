<link rel="stylesheet" type="text/css" href="gaya.css" />
<div id="login">
<fieldset>
<form name="form1" method="post" action="loginaksi.php" enctype="multipart/form-data">
  <h3>LOGIN</h3>
  <input name="username" type="text" id="username" placeholder="Username" required>
  <input name="password" type="password" id="password" placeholder="Password" required>
  <input type="submit" name="Submit" value="LOGIN">
</form>
<br>
<b><a style="color:teal;" href="index.php?p=registrasi"> Belum Terdaftar? Silahkan Registrasi</a></b> <br>
<br><a align="justify" href="index.php?p=lupapass">Klik Disini Jika Lupa Password Login</a>  
</fieldset>
</div>
