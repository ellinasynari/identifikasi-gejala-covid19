<table width ="30%">
<tr>
	<td>1. Pertama Anda login terlebih dahulu atau jika belum memiliki akun anda dapat melakukan registrasi terlebih dahulu</td>
</tr>
<tr>
	<td>2. Kemudian Anda pilih menu identifikasi</td>
</tr>
<tr>
	<td>3. Lalu Anda bisa menjawab pertanyaan sesuai gejala yang Anda alami</td>
</tr>
<tr>
	<td>4. Setelah Anda selesai menjawab pertanyaan, maka akan tampil penyakit sesuai dengan gejala yang anda pilih sebelumnya</td>
</tr>

</table>