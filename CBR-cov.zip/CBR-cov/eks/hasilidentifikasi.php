<?php if(!empty($_SESSION['namapas']) && ($_SESSION['passpas'])){
?>
<body style="background-repeat: no-repeat;background-size: cover;">
<div id="header">
  <div align="center">
    <p>
    <h4>Tabel Hasil identifikasi</h4>
    </p>

  </div>
</div>

<table>
	<tr>
		<th>No</th>
        <th>Nama user</th>
    	<th>Waktu identifikasi</th>
        <th>Gejala</th>
        <th>Hasil identifikasi</th>
    	<th>Nilai</th>
        <th>Aksi</th>
    	
    </tr>
  
   
   <?php
   	include "koneksi.php";
	$s = mysqli_query($kon, "select * from keterangan where nama='$_SESSION[namalengkap]' order by id_keterangan");
	$no = 1;
	while($data = mysqli_fetch_array($s)){
		$id_keterangan=$data['id_keterangan'];
		$id_identifikasi=$data['id_identifikasi'];
		$nama=$data['nama'];
		$tgl_identifikasi=$data['tgl_identifikasi'];
		$kd_penyakit=$data['kd_penyakit'];
		$nilai=$data['nilai'];
		echo "$sesion";
	?>

	 	<tr>
		
		<td align="center"><?php echo "$no" ?></td>
        <td align="center"><?php echo "$nama"; ?></td>
        <td align="center"><?php echo "$tgl_identifikasi"; ?></td>
		<td><?php 
				$sh = mysqli_query($kon, "select * from hasil_identifikasi where identifikasi='$id_identifikasi'");
				
				while($dh= mysqli_fetch_array($sh)){
					$sg = mysqli_query($kon,"select * from gejala where id_gejala='$dh[id_gejala]'");
					$dg = mysqli_fetch_array($sg);
					echo "$raquo; $dg[nm_gejala]<br>";
					}
				?> 
		</td>
		<td> <?php 
					$sp = mysqli_query($kon,"select * from penyakit where kd_penyakit='$kd_penyakit'");
					$dp = mysqli_fetch_array($sp);
					echo "$dp[nm_penyakit]";
					
				?> </td>
		<td><?php echo "$nilai";?></td>
		
	<td><a href="cetak.php?id=$id&identifikasi= <?php echo $id_identifikasi;?>" target="blank"> Cetak </a></td>

		</tr>
        <?php
		$no++;
		}
		?>
</table>	
<?php }else{
		echo "<script language='javascript'>
		alert('Silahkan login terlebih dahulu untuk melihat hasil identifikasi');
		window.location=('?p=login')</script>";
} ?>
</body>