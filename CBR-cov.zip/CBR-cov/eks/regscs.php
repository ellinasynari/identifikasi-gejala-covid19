<link rel="stylesheet" type="text/css" href="style.css" />
<div id="login">
<fieldset> <i><b>Registrasi Sukses, Silahkan Login Untuk Melanjutkan</b></i>
<form name="form1" method="post" action="loginaksi.php" enctype="multipart/form-data">
  <h3>LOGIN user</h3>
  <input name="username" type="text" id="username" placeholder="Username">
  <input name="password" type="password" id="password" placeholder="Password">
  <input type="submit" name="Submit" value="LOGIN">
</form>
</fieldset>
</div>
