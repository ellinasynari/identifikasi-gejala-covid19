<!Doctype html>
<head>
<link rel="stylesheet" href="css/all.min.css" media="screen" >
<style> 
.left-sidebar{ 
    background-color:white;
    box-shadow:2px 3px 3px 1px black;
    margin-top:0px;
    }
    
    li {
        color:black;
        padding:5px;
    }
 

</style>
<head> 
<div class="left-sidebar bg-white-500 box-shadow ">
                        <div class="sidebar-content">
                            <div class="user-info closed">
                                <img src="http://placehold.it/90/c2c2c2?text=User" alt="John Doe" class="img-circle profile-img">
                            </div>
                            <!-- /.user-info -->

                            <div class="sidebar-nav">
                                <ul class="side-nav color-gray">
                                    <li> 
                                        <a href="admin_edit_choice.php"> <span>Dashboard</span> </a> 
                                     
                                    </li>


                                    <li class="has-children">
                                            <li><a href="view-user-info.php"><span>INFO</span></a></li>
                                            <li><a href="change-password-user.php"> <span>GANTI PASSWORD</span></a></li>
                                            <li><a href="change-name-user.php"> <span>GANTI NAMA</span></a></li>
                                            <li><a href="previous-result.php"> <span>LIHAT HASIL SEBELUMNYA</span></a></li>
                                            <!-- <li><a href="user-details.php"></i><span>USER DETAILS</span></a></li> -->
                                
                                        </ul>
                                    </li>

                                           
                            </div>
                            <!-- /.sidebar-nav -->
                        </div>
                        <!-- /.sidebar-content -->
                    </div>
                    </html>