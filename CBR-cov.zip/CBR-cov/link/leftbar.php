<!Doctype html>
<head>
<link rel="stylesheet" href="css/all.min.css" media="screen" >
<style>
.left-sidebar{
    background-color:white;
    box-shadow:2px 3px 3px 1px black;
    margin-top:0px;
    }
    
    li {
        color:black;
        padding:5px;
    }
 

</style>
<head>
<div class="left-sidebar bg-white-500 box-shadow ">
                        <div class="sidebar-content">
                            <div class="user-info closed">
                                <img src="http://placehold.it/90/c2c2c2?text=User" alt="John Doe" class="img-circle profile-img">
                            </div>
                            <!-- /.user-info -->

                            <div class="sidebar-nav">
                                <ul class="side-nav color-gray">
                                    <li> 
                                        <a href="admin_edit_choice.php"> <span>Dashboard</span> </a> 
                                     
                                    </li>


                                    <li class="has-children">
                                            <li><a href="show_symptoms.php"><span>LIHAT GEJALA</span></a></li>
                                            <li><a href="show_disease.php"> <span>LIHAT PENYAKIT</span></a></li>
                                            <li><a href="add_symptoms.php"> <span>TAMBAH GEJALA</span></a></li>
                                            <li><a href="add_disease.php"></i><span>TAMBAH PENYAKIT</span></a></li>
                                            <li><a href="add-admin.php"></i><span>TAMBAH ADMIN</span></a></li>
                                            <li><a href="teerms.php" onclick="return confirm('Redirecting to you as a general user .');"></i> <span>ADMIN CHECKUPS</span></a></li>
                                            <li><a href="show-feedback.php"></i> <span>FEEDBACK</span></a></li>
                                            <li><a href="view_users.php"></i> <span>LIHAT USERS </span></a></li>
                                            <li><a href="change_password_admin.php"></i> <span>GANTI PASSWORD </span></a></li>
                                            <li><a href="change-admin-name.php"></i> <span>GANTI NAMA</span></a></li>

                                           
                                        </ul>
                                    </li>

                                           
                            </div>
                            <!-- /.sidebar-nav -->
                        </div>
                        <!-- /.sidebar-content -->
                    </div>
                    </html>